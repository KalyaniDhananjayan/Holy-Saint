'use client';

import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '@/context/AuthContext';

const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const userId = user?._id;

  const [cart, setCart] = useState([]);
  const prevUserIdRef = useRef(undefined);

  useEffect(() => {
    // Wait for auth to finish loading
    if (authLoading) {
      return;
    }

    const prevUserId = prevUserIdRef.current;
    prevUserIdRef.current = userId;

    // First load - skip
    if (prevUserId === undefined) {
      if (!userId) {
        // Initial load, not logged in
        const guest = JSON.parse(localStorage.getItem('guest_cart')) || [];
        setCart(guest);
      } else {
        // Initial load, logged in
        const userCart = JSON.parse(localStorage.getItem(`cart_${userId}`)) || [];
        setCart(userCart);
      }
      return;
    }

    // ----- User just LOGGED OUT -----
    if (prevUserId && !userId) {
      console.log('👋 User logged out - clearing cart');
      setCart([]);
      return;
    }

    // ----- User just LOGGED IN -----
    if (!prevUserId && userId) {
      const flowMode = localStorage.getItem('FLOW_MODE');
      const guestCart = JSON.parse(localStorage.getItem('guest_cart')) || [];
      const userCart = JSON.parse(localStorage.getItem(`cart_${userId}`)) || [];

      // Case 1: Logged in via checkout flow
      if (flowMode === 'CHECKOUT') {
        console.log('🛒 Login from checkout - preserving guest cart for checkout');
        setCart(guestCart);
        // DON'T clear guest_cart or merge - checkout will handle it
        return;
      }

      // Case 2: Normal login - merge carts
      console.log('🔄 Normal login - merging guest cart into user cart');
      const merged = [...userCart];

      guestCart.forEach(gItem => {
        const existing = merged.find(i => i.productId === gItem.productId);
        if (existing) {
          existing.quantity += gItem.quantity;
        } else {
          merged.push(gItem);
        }
      });

      // Save merged cart and clear guest cart
      localStorage.setItem(`cart_${userId}`, JSON.stringify(merged));
      localStorage.removeItem('guest_cart');
      setCart(merged);
      return;
    }

    // ----- User already logged in (switching users or refresh) -----
    if (userId) {
      const userCart = JSON.parse(localStorage.getItem(`cart_${userId}`)) || [];
      setCart(userCart);
    }

  }, [userId, authLoading]);

  const persist = (data) => {
    if (!userId) {
      localStorage.setItem('guest_cart', JSON.stringify(data));
    } else {
      localStorage.setItem(`cart_${userId}`, JSON.stringify(data));
    }
  };

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(i => i.productId === item.productId);
      let updated;

      if (existing) {
        updated = prev.map(i =>
          i.productId === item.productId
            ? { ...i, quantity: i.quantity + item.quantity }
            : i
        );
      } else {
        updated = [...prev, item];
      }

      persist(updated);
      return updated;
    });
  };

  const removeFromCart = (productId) => {
    setCart(prev => {
      const updated = prev.filter(i => i.productId !== productId);
      persist(updated);
      return updated;
    });
  };

  const clearCart = () => {
    if (!userId) {
      localStorage.removeItem('guest_cart');
    } else {
      localStorage.removeItem(`cart_${userId}`);
    }
    setCart([]);
  };

  const totalAmount = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        totalAmount,
        loading: authLoading
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);